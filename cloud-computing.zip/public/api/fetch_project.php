<?php


header('Content-Type: application/json');

require_once __DIR__ . '/../../src/controllers/ProjectController.php';

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing or invalid project ID']);
    exit;
}

$projectId = (int) $_GET['id'];

ProjectController::getProjectData($projectId);