<?php

require_once __DIR__ . '/../../src/controllers/ProjectController.php';

ProjectController::getAllProjects();
