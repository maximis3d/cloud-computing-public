const OPENWEATHER_API_KEY = "26cc64613e5e64a2c48fa3079da0ea48";

const pollutantThresholds = {
  CO: [
    { level: "Good", max: 4400 },
    { level: "Fair", max: 9400 },
    { level: "Moderate", max: 12400 },
    { level: "Poor", max: 15400 },
    { level: "Very Poor", max: Infinity }
  ],
  PM10: [
    { level: "Good", max: 20 },
    { level: "Fair", max: 50 },
    { level: "Moderate", max: 100 },
    { level: "Poor", max: 200 },
    { level: "Very Poor", max: Infinity }
  ],
  PM2_5: [
    { level: "Good", max: 10 },
    { level: "Fair", max: 25 },
    { level: "Moderate", max: 50 },
    { level: "Poor", max: 75 },
    { level: "Very Poor", max: Infinity }
  ],
  NO2: [
    { level: "Good", max: 40 },
    { level: "Fair", max: 70 },
    { level: "Moderate", max: 150 },
    { level: "Poor", max: 200 },
    { level: "Very Poor", max: Infinity }
  ]
};

function classifyPollutant(pollutant, value) {
  const thresholds = pollutantThresholds[pollutant];
  if (!thresholds) return "Unknown";
  for (const threshold of thresholds) {
    if (value < threshold.max) {
      return threshold.level;
    }
  }
  return "Unknown";
}

export async function fetchAirQualityData(lat, lon, resources) {
  const airQualityContainer = document.getElementById("air-info");

  const usesEarthMovingEquipment = resources.some(r =>
    ["dumper truck", "digger", "loader"].some(eq =>
      r.resource_type.toLowerCase().includes(eq)
    )
  );

  try {
    const res = await fetch(`http://api.openweathermap.org/data/2.5/air_pollution?lat=${lat}&lon=${lon}&appid=${OPENWEATHER_API_KEY}`);
    if (!res.ok) throw new Error('Failed to fetch current air quality data');
    const data = await res.json();

    const components = data.list[0]?.components || {};

    const pollutantsToCheck = ["CO", "PM10", "PM2_5", "NO2"];
    const pollutantMapping = { CO: "co", PM10: "pm10", PM2_5: "pm2_5", NO2: "no2" };

    let cancelWork = false;
    const pollutantStatuses = pollutantsToCheck.map(pollutant => {
      const value = components[pollutantMapping[pollutant]] ?? 0;
      const level = classifyPollutant(pollutant, value);
      if (level === "Poor" || level === "Very Poor") cancelWork = true;
      return { pollutant, value, level };
    });

    const statusMessages = pollutantStatuses
      .map(({ pollutant, value, level }) => `${pollutant}: ${value.toFixed(2)} μg/m³ (${level})`)
      .join("<br>");

    if (usesEarthMovingEquipment) {
      airQualityContainer.innerHTML = cancelWork
        ? `<strong>🚫 Construction work should NOT proceed.</strong><br>Pollutant levels:<br>${statusMessages}`
        : `<strong>✅ Air quality is acceptable for earth-moving equipment.</strong><br>Pollutant levels:<br>${statusMessages}`;
    } else {
      airQualityContainer.innerHTML = `<strong>ℹ️ No earth-moving equipment detected.</strong><br>Pollutant levels:<br>${statusMessages}`;
    }
  } catch (err) {
    airQualityContainer.textContent = `Error fetching air quality data: ${err.message}`;
  }
}

export async function fetchHistoricalAirQuality(lat, lon, dateString) {
  const airQualityContainer = document.getElementById("air-info");
  const start = Math.floor(new Date(dateString).getTime() / 1000);
  const end = start + 86400;

  try {
    const res = await fetch(`http://api.openweathermap.org/data/2.5/air_pollution/history?lat=${lat}&lon=${lon}&start=${start}&end=${end}&appid=${OPENWEATHER_API_KEY}`);
    if (!res.ok) throw new Error('Failed to fetch historical air quality data');

    const data = await res.json();
    if (!data.list?.length) {
      airQualityContainer.innerHTML = `<p>No historical air quality data available for ${dateString}.</p>`;
      return;
    }

    const pollutantMapping = { co: "CO", pm10: "PM10", pm2_5: "PM2_5", no2: "NO2" };
    const sums = {};
    const counts = {};

    data.list.forEach(({ components }) => {
      if (!components) return;
      for (const [key, label] of Object.entries(pollutantMapping)) {
        if (components[key] !== undefined) {
          sums[label] = (sums[label] || 0) + components[key];
          counts[label] = (counts[label] || 0) + 1;
        }
      }
    });

    const pollutantStatuses = Object.entries(sums).map(([pollutant, total]) => {
      const avgValue = total / counts[pollutant];
      return { pollutant, avgValue, level: classifyPollutant(pollutant, avgValue) };
    });

    airQualityContainer.innerHTML = `
      <h4>Historical Air Quality on ${dateString}</h4>
      Pollutant levels:<br>
      ${pollutantStatuses.map(({ pollutant, avgValue, level }) =>
        `${pollutant}: ${avgValue.toFixed(2)} μg/m³ (${level})`
      ).join("<br>")}
    `;
  } catch (err) {
    airQualityContainer.textContent = `Error fetching historical air quality data: ${err.message}`;
  }
}

export async function fetchAirQualityForecast(lat, lon) {
  const airQualityContainer = document.getElementById("air-info");
  airQualityContainer.innerHTML = `<p>Loading air quality forecast...</p>`;

  try {
    const res = await fetch(`http://api.openweathermap.org/data/2.5/air_pollution/forecast?lat=${lat}&lon=${lon}&appid=${OPENWEATHER_API_KEY}`);
    if (!res.ok) throw new Error('Failed to fetch air quality forecast data');

    const data = await res.json();
    if (!data.list?.length) {
      airQualityContainer.innerHTML = `<p>No air quality forecast data available.</p>`;
      return;
    }

    const pollutantMapping = { co: "CO", pm10: "PM10", pm2_5: "PM2_5", no2: "NO2" };
    const dailyData = {};

    data.list.forEach(({ dt, components }) => {
      const date = new Date(dt * 1000).toISOString().split('T')[0];
      if (!dailyData[date]) dailyData[date] = [];
      dailyData[date].push(components);
    });

    const forecastDays = Object.entries(dailyData).slice(0, 8);

    const forecastHtml = forecastDays.map(([date, readings]) => {
      const dateFormatted = new Date(date).toLocaleDateString(undefined, {
        weekday: 'short',
        month: 'short',
        day: 'numeric'
      });

      const sums = {}, counts = {};
      readings.forEach(components => {
        for (const [key, label] of Object.entries(pollutantMapping)) {
          if (components[key] !== undefined) {
            sums[label] = (sums[label] || 0) + components[key];
            counts[label] = (counts[label] || 0) + 1;
          }
        }
      });

      const summaries = Object.entries(sums).map(([pollutant, total]) => {
        const avg = total / counts[pollutant];
        const level = classifyPollutant(pollutant, avg);
        return `<div class="pollutant-line">${pollutant}: <strong>${avg.toFixed(2)} μg/m³</strong> (${level})</div>`;
      }).join("");

      return `
        <div class="forecast-card">
          <div class="forecast-date">${dateFormatted}</div>
          ${summaries}
        </div>
      `;
    }).join("");

    airQualityContainer.innerHTML = `
      <h4>8-Day Air Quality Forecast</h4>
      <div class="forecast-grid">${forecastHtml}</div>
    `;
  } catch (err) {
    airQualityContainer.textContent = `Error fetching air quality forecast data: ${err.message}`;
  }
}
