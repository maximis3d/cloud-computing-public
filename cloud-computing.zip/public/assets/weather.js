const OPENWEATHER_API_KEY = "26cc64613e5e64a2c48fa3079da0ea48";

export async function fetchWeatherData(lat, lon, resources) {
  const weatherContainer = document.getElementById('weather-info');

  const usesCrane = resources.some(r => r.resource_type.toLowerCase().includes("crane"));
  const usesDiggers = resources.some(r =>
    r.resource_type.toLowerCase().includes("digger") ||
    r.resource_type.toLowerCase().includes("dumper")
  );

  try {
    const res = await fetch(`https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${OPENWEATHER_API_KEY}&units=metric`);
    const data = await res.json();

    const windSpeed = data.wind?.speed || 0;
    const weatherDesc = data.weather[0]?.description?.toLowerCase() || "unknown";

    const recommendations = [];

    if (usesCrane && windSpeed > 9) {
      recommendations.push("🚫 Crane operations should not be carried out due to high wind speeds.");
    }

    const severeRainTerms = ["heavy", "intense", "extreme"];
    const isSevereRain = severeRainTerms.some(term => weatherDesc.includes(term));

    if (usesDiggers && isSevereRain) {
      recommendations.push("⏳ Digger and dumper truck works may be delayed due to heavy rainfall.");
    }

    weatherContainer.innerHTML = `
      <p><strong>Current Weather:</strong> ${toTitleCase(weatherDesc)}</p>
      <p><strong>Wind Speed:</strong> ${windSpeed} m/s</p>
      ${recommendations.length
        ? `<h4>Recommendations:</h4><ul>${recommendations.map(r => `<li>${r}</li>`).join('')}</ul>`
        : "<p>No weather-related concerns at the moment.</p>"}
    `;
  } catch (err) {
    weatherContainer.innerHTML = `<p>Error loading current weather data: ${err.message}</p>`;
  }
}

export async function fetchWeatherForecast(lat, lon, cnt = 8) {
  const weatherContainer = document.getElementById('weather-info');
  try {
    const res = await fetch(`https://api.openweathermap.org/data/2.5/forecast/daily?lat=${lat}&lon=${lon}&cnt=${cnt}&units=metric&appid=${OPENWEATHER_API_KEY}`);
    if (!res.ok) throw new Error('Failed to fetch weather forecast');
    const data = await res.json();

    weatherContainer.innerHTML = `<h4>${cnt}-Day Forecast</h4><div class="forecast-grid">` + data.list.map(day => {
      const date = new Date(day.dt * 1000).toLocaleDateString();
      const description = toTitleCase(day.weather[0].description);
      const temp = day.temp.day.toFixed(1);

      return `
        <div class="forecast-card">
          <strong>${date}</strong>
          <p>${description}</p>
          <p><strong>Temperature:</strong> ${temp}°C</p>
        </div>
      `;
    }).join('') + '</div>';
  } catch (err) {
    weatherContainer.innerHTML = `<p>Error loading forecast: ${err.message}</p>`;
  }
}


export async function fetchHistoricalWeather(lat, lon, dateString) {
  const weatherContainer = document.getElementById('weather-info');

  const start = Math.floor(new Date(dateString).getTime() / 1000);
  const end = start + 86400;

  try {
    const res = await fetch(`https://history.openweathermap.org/data/2.5/history/city?lat=${lat}&lon=${lon}&start=${start}&end=${end}&units=metric&appid=${OPENWEATHER_API_KEY}`);
    if (!res.ok) throw new Error('Failed to fetch historical weather');
    const data = await res.json();

    if (!data.list || data.list.length === 0) {
      weatherContainer.innerHTML = `<p>No historical data available for ${dateString}.</p>`;
      return;
    }

    const temps = data.list.map(entry => entry.main.temp);
    const avgTemp = (temps.reduce((a, b) => a + b, 0) / temps.length).toFixed(1);
    const condition = data.list[0]?.weather[0]?.description || 'unknown';

    weatherContainer.innerHTML = `
      <h4>Weather on ${dateString}</h4>
      <p><strong>Average Temp:</strong> ${avgTemp}°C</p>
      <p><strong>Condition:</strong> ${toTitleCase(condition)}</p>
    `;
  } catch (err) {
    weatherContainer.innerHTML = `<p>Error fetching historical data: ${err.message}</p>`;
  }
}

function toTitleCase(str) {
  return str
    .split(' ')
    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
    .join(' ');
}
