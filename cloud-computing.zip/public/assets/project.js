import initMap from './map.js';
import { fetchWeatherData, fetchWeatherForecast, fetchHistoricalWeather } from './weather.js';
import { fetchAirQualityData, fetchHistoricalAirQuality, fetchAirQualityForecast } from './air_quality.js';

async function fetchProjectData() {
  const projectId = new URLSearchParams(window.location.search).get('id');
  try {
    const response = await fetch(`./public/api/fetch_project.php?id=${projectId}`);
    if (!response.ok) throw new Error('Failed to fetch project data');
    const projectData = await response.json();
    renderProjectDetails(projectData);
  } catch (error) {
    console.error('Error fetching data:', error);
    showError(error.message);
  }
}

function renderProjectDetails(data) {
  const container = document.getElementById('project-details-container');

  if (!data.project) {
    container.innerHTML = "<p>Project not found.</p>";
    return;
  }

  const [latitude, longitude] = data.project.geolocation.split(',').map(Number);
  window.latitude = latitude;
  window.longitude = longitude;
  window.resources = data.resources;

  container.innerHTML = `
    <div id="project-title">
      <h2>${data.project.project_name}</h2>
    </div>
    <p><strong>Description:</strong> ${data.project.description}</p>
    <p><strong>Manager:</strong> ${data.project.manager}</p>
    <p><strong>Location:</strong> ${data.project.location}</p>

    <div class="data-controls">
      <label for="data-view">View:</label>
      <select id="data-view">
        <option value="current">Current</option>
        <option value="forecast">8-Day Forecast</option>
        <option value="historical">Historical</option>
      </select>
      <input type="date" id="historical-date" style="display:none;" max="${new Date().toISOString().split('T')[0]}">
    </div>

    <h3>Weather Conditions</h3>
    <div id="weather-info">
      <p>Loading weather data...</p>
    </div>

    <h3>Air Quality</h3>
    <div id="air-info">
      <p>Loading air quality data...</p>
    </div>

    <h3>Location on Map</h3>
    <div id="map" style="width: 100%; height: 400px;"></div>

    <a href="index.php">← Back to Project List</a>
  `;

  initMap(latitude, longitude);
  fetchWeatherData(latitude, longitude, window.resources);
  fetchAirQualityData(latitude, longitude, window.resources);
}

function showError(message) {
  const container = document.getElementById('project-details-container');
  container.innerHTML = `<div class="error-message">${message}</div>`;
}

// Unified event listener
document.addEventListener('change', (e) => {
  if (e.target.id === 'data-view' || e.target.id === 'historical-date') {
    const view = document.getElementById('data-view').value;
    const dateInput = document.getElementById('historical-date');
    const date = dateInput.value;

    // Toggle date visibility
    dateInput.style.display = view === 'historical' ? 'inline-block' : 'none';

    // Handle view changes
    if (view === 'current') {
      fetchWeatherData(window.latitude, window.longitude, window.resources);
      fetchAirQualityData(window.latitude, window.longitude, window.resources);
    } else if (view === 'forecast') {
      fetchWeatherForecast(window.latitude, window.longitude, 8);
      fetchAirQualityForecast(window.latitude, window.longitude);
    } else if (view === 'historical' && date) {
      fetchHistoricalWeather(window.latitude, window.longitude, date);
      fetchHistoricalAirQuality(window.latitude, window.longitude, date);
    }
  }
});

document.addEventListener('DOMContentLoaded', fetchProjectData);
