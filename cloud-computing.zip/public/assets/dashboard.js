// Fetches all projects from the API
async function fetchProjectData() {
  try {
    const response = await fetch('./public/api/fetch_projects.php');
    if (!response.ok) {
      throw new Error('Failed to fetch projects data');
    }
    return await response.json();
  } catch (error) {
    console.error("Error fetching data:", error);
    showError(error.message);
    return [];
  }
}

// Renders the project table with project data
function renderProjectTable(data) {
  const tableContainer = document.getElementById("project-table-container");

  if (data.length === 0) {
    tableContainer.innerHTML = "<p>No projects available.</p>";
    return;
  }

  const tableHTML = generateTableHTML(data);
  tableContainer.innerHTML = tableHTML;
}

// Generates structure for table
function generateTableHTML(data) {
  return `
    <table id="project-table">
      <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Description</th>
          <th>Manager</th>
          <th>Location</th>
          <th>Geolocation</th>
          <th>Details</th> <!-- Link to the individual project details page -->
        </tr>
      </thead>
      <tbody>
        ${data.map(project => `
          <tr>
            <td>${project.project_id}</td>
            <td>${project.project_name}</td>
            <td>${project.description}</td>
            <td>${project.manager}</td>
            <td>${project.location}</td>
            <td>${project.geolocation}</td>
            <!-- Link to individual project page (passing the project ID) -->
            <td><a href="project.php?id=${project.project_id}">View Details</a></td>
          </tr>
        `).join('')}
      </tbody>
    </table>
  `;
}

function showError(message) {
  const tableContainer = document.getElementById("project-table-container");
  tableContainer.innerHTML = `<div class="error-message">${message}</div>`;
}

document.addEventListener("DOMContentLoaded", async () => {
  const projectData = await fetchProjectData();
  renderProjectTable(projectData);
});
