DROP TABLE IF EXISTS project_resources;
DROP TABLE IF EXISTS resources;
DROP TABLE IF EXISTS projects;

CREATE TABLE IF NOT EXISTS projects(
    `project_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `project_name` VARCHAR(255) NOT NULL,
    `description` TEXT NOT NULL,
    `manager` VARCHAR(255) NOT NULL,
    `location` VARCHAR(255) NOT NULL,
    `geolocation` VARCHAR(255) NOT NULL,

    PRIMARY KEY (project_id)
);

CREATE TABLE IF NOT EXISTS resources(
    `resource_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `resource_type` VARCHAR(255) NOT NULL,
    `conditions_of_use` TEXT NOT NULL,

    PRIMARY KEY (resource_id)
);

CREATE TABLE IF NOT EXISTS project_resources(
    `project_id` INT UNSIGNED NOT NULL,
    `resource_id` INT UNSIGNED NOT NULL,

    PRIMARY KEY (`project_id`, `resource_id`),
    FOREIGN KEY (`project_id`) REFERENCES `projects`(`project_id`) ON DELETE CASCADE,
    FOREIGN KEY (`resource_id`) REFERENCES `resources`(`resource_id`) ON DELETE CASCADE
);

INSERT INTO projects (project_name, `description`, manager, `location`, geolocation)
VALUES 
    ("NEEST", "A new university building with lab spaces, meeting rooms, breakout areas, kitchen areas and WC facilities.", "Chelsea Dawson", "Northumbria University, Ellison Terrace, Newcastle upon Tyne, NE1 8ST", "54.976414676146824, -1.6066366875533187"),
    ("CHASE", "A new university building with lab spaces, meeting rooms, breakout areas, kitchen areas and WC facilities.", "Peter Duncan", "Northumbria University, Ellison Terrace, Newcastle upon Tyne, NE1 8ST", "54.97919158255862, -1.6064863942439456"),
    ("HMRC", "An office space for a public sector client to include gym space, staff rooms with kitchen areas, toilet facilities, meeting rooms and breakout areas.", "Dan Smith", "New Bridge Street, Newcastle upon Tyne, NE1 2SW", "54.97419179801806, -1.6113036886189427"),
    ("St James Park", "An extension to the existing football stadium to include a clubhouse for coaching non-professional players and hosting events. To include a small field, an exhibition room, toilet facilities and a kitchen.", "Chelsea Dawson", "Newcastle United Football Co Ltd, St. James Park, Strawberry Place, Newcastle upon Tyne, NE1 4ST", "54.97470900180268, -1.6204767255123336");

INSERT INTO resources (resource_type, conditions_of_use)
VALUES
    ("Crane", "Do not use in high wind"),
    ("Drill", "Do not use in heavy rain"),
    ("Dumper Truck", "Do not use in heavy rain. Has CO2 emissions so don't use if air quality CO, PM10, PM2.5 or NO2 readings are moderate or poorer."),
    ("Digger", "Do not use in heavy rain. Has CO2 emissions so don't use if air quality CO, PM10, PM2.5 or NO2 readings are moderate or poorer."),
    ("Loader", "Do not use in heavy rain. Has CO2 emissions so don't use if air quality CO, PM10, PM2.5 or NO2 readings are moderate or poorer."),
    ("Concrete Mixer", "Do not use in heavy rain");

INSERT INTO project_resources (project_id, resource_id)
VALUES
    (1, 1),
    (1, 2),
    (1, 3),
    (1, 4),
    (1, 5),
    (2, 1),
    (2, 2),
    (2, 3),
    (2, 4),
    (2, 5),
    (3, 1),
    (3, 3),
    (3, 4),
    (3, 5),
    (3, 6),
    (4, 1),
    (4, 3),
    (4, 5),
    (4, 6);
