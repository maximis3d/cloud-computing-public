<?php

require_once __DIR__ . '/../db.php';

class Project
{
    private $db;

    public function __construct() {
        $this->db = new Database();
    }

    public function all() {
        $sql = "SELECT project_id, project_name, description, manager, location, geolocation FROM projects";
        return $this->db->fetchRows($sql);
    }

    public function find($id) {
        $sql = "SELECT project_id, project_name, description, manager, location, geolocation FROM projects WHERE project_id = ?";
        return $this->db->fetchRows($sql, [$id]);
    }

    public function getProjectWithResources($projectId) {
        $projectSql = "SELECT project_id, project_name, description, manager, location, geolocation FROM projects WHERE project_id = ?";
        $project = $this->db->fetchRows($projectSql, [$projectId]);
    
        if (empty($project)) {
            return null;
        }
    
        $resourceSql = "
            SELECT r.resource_type, r.conditions_of_use
            FROM resources r
            JOIN project_resources pr ON r.resource_id = pr.resource_id
            WHERE pr.project_id = ?";
        $resourceResult = $this->db->query($resourceSql, [$projectId]);
    
        $resources = [];
        while ($row = $resourceResult->fetch_assoc()) {
            $resources[] = $row;
        }
    
        return [
            'project' => $project[0],
            'resources' => $resources
        ];
    }
    
    
    public function __destruct() {
        $this->db->close();
    }
}
