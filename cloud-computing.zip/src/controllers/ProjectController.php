<?php
require_once __DIR__ . '/../models/Project.php';

class ProjectController
{
    public static function getAllProjects() {
        $projectModel = new Project();
        $projects = $projectModel->all();

        header('Content-Type: application/json');
        echo json_encode($projects);
    }

    public static function getProjectById($id) {
        $projectModel = new Project();
        $project = $projectModel->find($id);

        header('Content-Type: application/json');
        echo json_encode($project);
    }

    public static function getProjectData($projectId) {
        $projectModel = new Project();
        $data = $projectModel->getProjectWithResources($projectId);

        if ($data) {
            header('Content-Type: application/json');
            echo json_encode($data);
        } else {
            header('Content-Type: application/json');
            http_response_code(404);
            echo json_encode(["error" => "Project not found"]);
        }
    }
}
