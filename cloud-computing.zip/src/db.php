<?php

const CONFIG = [
    'host' => '127.0.0.1',
    'db'   => 'projects',
    'user' => 'root',
    'pass' => 'NewRootPassword123!',
];

class Database {
    private $mysqli;

    public function __construct() {
        $this->connect();
    }

    private function connect() {
        $this->mysqli = new mysqli(
            CONFIG['host'],
            CONFIG['user'],
            CONFIG['pass'],
            CONFIG['db']
        );

        if ($this->mysqli->connect_error) {
            $this->handleError('Connection failed: ' . $this->mysqli->connect_error);
        }

        $this->mysqli->set_charset('utf8mb4');
    }

    public function query($sql, $params = []) {
        $stmt = $this->mysqli->prepare($sql);

        if (!$stmt) {
            $this->handleError('Prepare failed: ' . $this->mysqli->error);
        }

        if ($params) {
            $types = str_repeat('s', count($params));
            $stmt->bind_param($types, ...$params);
        }

        if (!$stmt->execute()) {
            $this->handleError('Query failed: ' . $stmt->error);
        }

        return $stmt->get_result();
    }

    public function fetchRows($sql, $params = []) {
        $result = $this->query($sql, $params);
        return $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
    }

    public function close() {
        $this->mysqli->close();
    }

    private function handleError($message) {
        error_log($message);

        header('Content-Type: application/json');
        echo json_encode(['error' => $message]);
        exit;
    }
}
