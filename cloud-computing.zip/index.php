<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Project Dashboard</title>
  <link rel="stylesheet" href="/css/index.css">
</head>

<body>

  <div class="container">
    <h1>Project Dashboard</h1>

    <div id="project-table-container"></div>
  </div>

  <script type="module" src="/public/assets/dashboard.js"></script>

</body>

</html>
