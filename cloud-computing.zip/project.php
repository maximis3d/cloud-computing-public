<?php

require_once __DIR__ . '/src/controllers/ProjectController.php';

$projectId = isset($_GET['id']) ? $_GET['id'] : null;
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Project Details</title>
  <link rel="stylesheet" href="/css/project.css">
  <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDnMCGeb3WENqlV3Nye9H_z-MFZ2fTIKvA&callback=initMap"  type="text/javascript"></script>
</head>

<body>
  <div class="container">
    <div id="project-details-container"></div>
  </div>
  
  <script type="module" src="/public/assets/project.js"></script>

</body>

</html>
